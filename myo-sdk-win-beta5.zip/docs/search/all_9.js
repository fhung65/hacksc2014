var searchData=
[
  ['onaccelerometerdata',['onAccelerometerData',['../classmyo_1_1_device_listener.html#ad983924f2a2b0eb3c18047a52ed3b5fb',1,'myo::DeviceListener']]],
  ['onarmlost',['onArmLost',['../classmyo_1_1_device_listener.html#a46979f435f1dd7f532514af996e7e3b5',1,'myo::DeviceListener']]],
  ['onarmrecognized',['onArmRecognized',['../classmyo_1_1_device_listener.html#a10ad07ee4ee1fee532bda6237fc82616',1,'myo::DeviceListener']]],
  ['onconnect',['onConnect',['../classmyo_1_1_device_listener.html#a29ab3696d66a787e296017ce74abcee9',1,'myo::DeviceListener']]],
  ['ondisconnect',['onDisconnect',['../classmyo_1_1_device_listener.html#a83fd365a88abf5dc947374e69459c5cb',1,'myo::DeviceListener']]],
  ['ongyroscopedata',['onGyroscopeData',['../classmyo_1_1_device_listener.html#ad9ac9d1d839804022c759b6f225a0032',1,'myo::DeviceListener']]],
  ['onorientationdata',['onOrientationData',['../classmyo_1_1_device_listener.html#adaee14d3c4f9df61899ac8aa95b6bbc6',1,'myo::DeviceListener']]],
  ['onpair',['onPair',['../classmyo_1_1_device_listener.html#af2b09ca659ea0a2f604117d1d49af2e1',1,'myo::DeviceListener']]],
  ['onpose',['onPose',['../classmyo_1_1_device_listener.html#a2d2e3595a1ec313c770b7efce374803f',1,'myo::DeviceListener']]],
  ['onrssi',['onRssi',['../classmyo_1_1_device_listener.html#a78c404fbd7649e11aed5c4d10705df74',1,'myo::DeviceListener']]],
  ['onunpair',['onUnpair',['../classmyo_1_1_device_listener.html#afd9a510fbf547fa764a7e80f733b1081',1,'myo::DeviceListener']]],
  ['operator_21_3d',['operator!=',['../classmyo_1_1_pose.html#afdcb3e3d22c74cfaffd7f0f49dd1b576',1,'myo::Pose::operator!=(Pose other) const '],['../classmyo_1_1_pose.html#a0033270d28a525dfd0f65acdb17a5ac4',1,'myo::Pose::operator!=(Pose pose, Pose::Type type)'],['../classmyo_1_1_pose.html#a160eab5465da08ad9bf830f6d21c4ed9',1,'myo::Pose::operator!=(Pose::Type type, Pose pose)']]],
  ['operator_2a',['operator*',['../classmyo_1_1_quaternion.html#a32c9121b395c4da10325006985e3404e',1,'myo::Quaternion']]],
  ['operator_2a_3d',['operator*=',['../classmyo_1_1_quaternion.html#a579a8b4c6fcb2536d22a92893816297a',1,'myo::Quaternion']]],
  ['operator_3c_3c',['operator&lt;&lt;',['../classmyo_1_1_pose.html#af2a9a5957dea26f6185d759ab9e0705e',1,'myo::Pose']]],
  ['operator_3d',['operator=',['../classmyo_1_1_quaternion.html#a40a4aceb4f3bdbf7431bcc146888c16e',1,'myo::Quaternion::operator=()'],['../classmyo_1_1_vector3.html#affe465772cfd14eef41b1207bfacb435',1,'myo::Vector3::operator=()']]],
  ['operator_3d_3d',['operator==',['../classmyo_1_1_pose.html#a693ce11b0eb9ba63873b4f5ad3bc5311',1,'myo::Pose::operator==(Pose other) const '],['../classmyo_1_1_pose.html#ab6362ecd71ac5c8abf927d556375450c',1,'myo::Pose::operator==(Pose pose, Pose::Type t)'],['../classmyo_1_1_pose.html#a1df7ef36c37e2f89fd405074d32364c0',1,'myo::Pose::operator==(Pose::Type type, Pose pose)']]],
  ['operator_5b_5d',['operator[]',['../classmyo_1_1_vector3.html#ab05204ddeab72969c02f3b0a0985f8e9',1,'myo::Vector3']]]
];
