var searchData=
[
  ['the_20myo_20sdk',['The Myo SDK',['../the-sdk.html',1,'index']]],
  ['tostring',['toString',['../classmyo_1_1_pose.html#aa0ebf43892a3b293c661b18c058013b6',1,'myo::Pose']]],
  ['type',['type',['../classmyo_1_1_pose.html#a9797babccf953c61b9b464dc494d29dc',1,'myo::Pose::type() const '],['../classmyo_1_1_pose.html#ae6566276cac4694db8e9e5873c5b0acf',1,'myo::Pose::Type()']]]
];
