var searchData=
[
  ['legal_20notices',['Legal Notices',['../legal-notices.html',1,'']]]
];
