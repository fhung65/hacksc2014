var classmyo_1_1_myo =
[
    [ "VibrationType", "classmyo_1_1_myo.html#a13be9e9075fb3cf5d47ba491306f3271", [
      [ "vibrationShort", "classmyo_1_1_myo.html#a13be9e9075fb3cf5d47ba491306f3271a8d7b7af0de494b200a3f94332e6da3f7", null ],
      [ "vibrationMedium", "classmyo_1_1_myo.html#a13be9e9075fb3cf5d47ba491306f3271ab06d9e4bccbc98add36e397599835833", null ],
      [ "vibrationLong", "classmyo_1_1_myo.html#a13be9e9075fb3cf5d47ba491306f3271ac5ab3818975f6f0aa3234f614941b805", null ]
    ] ],
    [ "requestRssi", "classmyo_1_1_myo.html#a38477309f70709e2bf1d3d1a82d30e00", null ],
    [ "vibrate", "classmyo_1_1_myo.html#a5364a3d446c8d60fdc381b0bb2cb6c92", null ],
    [ "Hub", "classmyo_1_1_myo.html#aea14f5495b4697c28ed665a9054acf5e", null ]
];